﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BuildWall : MonoBehaviour {


    float cubeHeight = 0.98f;
    float cubeWidth = 0.98f;

    // Use this for initialization
    void Start () {
        float referenceX = -5f;
        float referenceY = 0.51f;
        float referenceZ = 3f;

        

        GameObject cube = new GameObject();

        for (int i = 0; i <= 15; i++)
        {
            for (int j = 0; j <= 15; j++)
            {
                Vector3 position_ = new Vector3(referenceX +
                j * cubeWidth, referenceY + i * cubeHeight, 0);
                Color newColor = new Color(Random.Range(0.0f, 1f), Random.Range(0.0f, 1f), Random.Range(0.0f, 1f));
                
                Rigidbody gameObjectsRigidBody = cube.AddComponent<Rigidbody>();
                gameObjectsRigidBody.mass = 1;
          
                cube.transform.position = position_;
                cube = GameObject.CreatePrimitive(PrimitiveType.Cube);
                cube.GetComponent<MeshRenderer>().material.color = newColor;
            }
        }
        //Wall();
	}

    // Update is called once per frame
    void Update () {
		
	}

 
}
